const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Settings API
  getSettings: () => ipcRenderer.invoke('get-settings'),
  saveSettings: (settings) => ipcRenderer.invoke('save-settings', settings),
  
  // Testing API
  testConnection: () => ipcRenderer.invoke('test-connection'),
  testPrinter: () => ipcRenderer.invoke('test-printer'),
  
  // Listeners
  onStatusUpdate: (callback) => 
    ipcRenderer.on('status-update', (_, data) => callback(data)),
  
  // Remove listeners
  removeStatusUpdateListener: () => 
    ipcRenderer.removeAllListeners('status-update')
}); 